<?php
function perform_database_action()
{
   mysql_query(“INSERT into table_name (col1, col2, col3) VALUES ('$value1','$value2', '$value3');
}


$data=(
col1=>$value1,
col2=>value2,
col3=>value3
);

global $wpdb;
$table_name=$wpdb->$prefix."mytable";
$wpdbb->insert($table_name, $data);

//###################################################  Master Contact Form  Start #####################################

//#############################################################
//Master Form here
//Master Contact Form
// Add the shortcode
function master_contact_form_shortcode() {
    ob_start();
    ?>
	<style>
    .hover-button1 {
      width:150px !important; 
      background-color: #FFC909 !important; 
      border: 5px solid #FFC909 !important;  
      color: #262325 !important; 
    }

    .hover-button1:hover {
      background-color: #232323 !important; 
      border: 5px solid #232323 !important;  
      color:#FFF !important; 
    } 
    </style>
    <div id="custom-contact-form">
        <form style="width: 100%;" method="post" action="">
            
            
            <input style="width: 100%;" type="text" name="name" placeholder="Enter Name" required>
			</br>
			
            <input style="width: 100%;" type="email" name="email" placeholder="Enter Email" required>
			</br>

            <input style="width: 100%;" type="tel" name="mobile" pattern="[0-9]{10}" placeholder="Enter 10-digit mobile number" required>
			</br>

            
            <select style="width: 100%;" name="state" required>
                <option value="" selected disabled>Select your state</option>
                <option value="Andhra Pradesh">Andhra Pradesh</option>
                <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                <option value="Assam">Assam</option>
                <option value="Bihar">Bihar</option>
                <option value="Chhattisgarh">Chhattisgarh</option>
                <option value="Goa">Goa</option>
                <option value="Gujarat">Gujarat</option>
                <option value="Haryana">Haryana</option>
                <option value="Himachal Pradesh">Himachal Pradesh</option>
                <option value="Jharkhand">Jharkhand</option>
                <option value="Karnataka">Karnataka</option>
                <option value="Kerla">Kerla</option>
                <option value="Madhya Pradesh">Madhya Pradesh</option>
                <option value="Maharashtra">Maharashtra</option>
                <option value="Manipur">Manipur</option>
                <option value="Meghalaya">Meghalaya</option>
                <option value="Mizoram">Mizoram</option>
                <option value="Nagaland">Nagaland</option>
                <option value="Odisha">Odisha</option>
                <option value="Punjab">Punjab</option>
                <option value="Rajasthan">Rajasthan</option>
                <option value="Sikkim">Sikkim</option>
                <option value="Tamil Nadu">Tamil Nadu</option>
                <option value="Telangana">Telangana</option>
                <option value="Tripura">Tripura</option>
                <option value="Uttar Pradesh">Uttar Pradesh</option>
                <option value="Uttarakhand">Uttarakhand</option>
                <option value="West Bengal">West Bengal</option>
                <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                <option value="Chandigarh">Chandigarh</option>
                <option value="Dadra & Nagar Haveli and Daman & Diu">Dadra & Nagar Haveli and Daman & Diu</option>
                <option value="Delhi">Delhi</option>
                <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                <option value="Puducherry">Puducherry</option>
                <option value="Ladakh">Ladakh</option>
            </select>
            </br>

           
            <input  style="width: 100%;" type="text" name="city" placeholder="Enter City Name" required>
            </br>

           
            <select style="width: 100%;" name="query_type" required>
                <option value="" selected disabled>How do you want to partner with BLive?</option>
                <option value="multi_brand_franchise_owner">Multi Brand Franchise Owner</option>
                <option value="fleet_operator">Fleet Operator</option>
                <option value="enterprise_solution">Enterprise solution</option>
                <option value="want_to_buy_an_EV">Want to buy an EV</option>
            </select>
            </br>

           
            <textarea style="width: 100%;" name="comment_message" rows="5"placeholder="Enter Message" required></textarea>
			</br>
            <input class="hover-button1" type="submit" name="submit" value="Submit">
        </form>
    </div>
    <?php
    return ob_get_clean();
}

// Handle form submission and validation
function handle_master_contact_form() {
    if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["submit"])) {
        $name = sanitize_text_field($_POST["name"]);
        $email = sanitize_email($_POST["email"]);
        $mobile = sanitize_text_field($_POST["mobile"]);
        $state = sanitize_text_field($_POST["state"]);
        $city = sanitize_text_field($_POST["city"]);
        $query_type = sanitize_text_field($_POST["query_type"]);
        $comment_message = esc_textarea($_POST["comment_message"]);

        // Basic form validation
        $errors = array();

        if (empty($name)) {
            $errors[] = 'Please enter your name.';
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Please enter a valid email address.';
        }

        if (empty($mobile) || !preg_match('/^[0-9]{10}$/', $mobile)) {
            $errors[] = 'Please enter a valid 10-digit mobile number.';
        }

        if (empty($state)) {
            $errors[] = 'Please select your state.';
        }

        if (empty($city)) {
            $errors[] = 'Please enter your city name.';
        }

        if (empty($query_type)) {
            $errors[] = 'Please sellect a your query.';
        }
		/*
        if (empty($comment_message)) {
            $errors[] = 'Please enter your message.';
        }
        */

        if (empty($errors)) {
            // No validation errors, proceed with sending the email
            //$to = "rajiv@blive.co.in"; // Replace with your email address

            //$to = $query_type === 'Fleet Operator'||'Franchisee' ? 'rajiv@blive.co.in' : 'rajivcq@email.com';
            $to = '';
            $headers = "From:$name <$email>";
            $subject="Enquery Form From BLive.Co.In";

            
            // $comment_message .= "\n\nState: $state\nCity: $city\nMobile Number: $mobile";
            $body= "\n\nName: $name\nEmail: $email\nMobile Number: $mobile\nState: $state\nCity: $city\nHow do you want to partner with BLive?: $query_type\nYour Message:$comment_message";

            switch ($query_type) {
                case 'multi_brand_franchise_owner':
                case 'want_to_buy_an_EV':
                    $to = 'pratishtha@blive.co.in'; // Replace with your North India email address
                    break;
    
                case 'fleet_operator':
                case 'enterprise_solution':
                    $to = 'kishor@blive.co.in'; // Replace with your South India email address
                    break;
    
                default:
                    // Default email address if city is not specified
                    $to = 'default@email.com';
            }

    
            

            $mail_success = wp_mail($to, $subject, $body, $headers);

            if ($mail_success) {
                // Redirect to the thank you page
                wp_redirect(home_url('/thank-you'));
                exit;
            } else {
                echo '<p class="error-message">Sorry, there was an error sending your message. Please try again later.</p>';
            }
        } else {
            // Display validation errors
            echo '<div class="error-message">' . implode('<br>', $errors) . '</div>';
        }
    }
}

// Hook the functions to WordPress actions
add_shortcode('master_contact_form', 'master_contact_form_shortcode');
add_action('init', 'handle_master_contact_form');




//##################################################################################

//#############################################################
//Master Form here
//Master Contact Form
// Add the shortcode
function master_contact_form_shortcode() {
    ob_start();
    ?>
	<style>
    .hover-button1 {
      width:150px !important; 
      background-color: #FFC909 !important; 
      border: 5px solid #FFC909 !important;  
      color: #262325 !important; 
    }

    .hover-button1:hover {
      background-color: #232323 !important; 
      border: 5px solid #232323 !important;  
      color:#FFF !important; 
    } 
    </style>
    <div id="custom-contact-form">
        <form style="width: 100%;" method="post" action="">
            
            
            <input style="width: 100%;" type="text" name="name" placeholder="Enter Name" required>
			</br>
			
            <input style="width: 100%;" type="email" name="email" placeholder="Enter Email" required>
			</br>

            <input style="width: 100%;" type="tel" name="mobile" pattern="[0-9]{10}" placeholder="Enter 10-digit mobile number" required>
			</br>

            
            <select style="width: 100%;" name="state" required>
                <option value="" selected disabled>Select your state</option>
                <option value="Andhra Pradesh">Andhra Pradesh</option>
                <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                <option value="Assam">Assam</option>
                <option value="Bihar">Bihar</option>
                <option value="Chhattisgarh">Chhattisgarh</option>
                <option value="Goa">Goa</option>
                <option value="Gujarat">Gujarat</option>
                <option value="Haryana">Haryana</option>
                <option value="Himachal Pradesh">Himachal Pradesh</option>
                <option value="Jharkhand">Jharkhand</option>
                <option value="Karnataka">Karnataka</option>
                <option value="Kerla">Kerla</option>
                <option value="Madhya Pradesh">Madhya Pradesh</option>
                <option value="Maharashtra">Maharashtra</option>
                <option value="Manipur">Manipur</option>
                <option value="Meghalaya">Meghalaya</option>
                <option value="Mizoram">Mizoram</option>
                <option value="Nagaland">Nagaland</option>
                <option value="Odisha">Odisha</option>
                <option value="Punjab">Punjab</option>
                <option value="Rajasthan">Rajasthan</option>
                <option value="Sikkim">Sikkim</option>
                <option value="Tamil Nadu">Tamil Nadu</option>
                <option value="Telangana">Telangana</option>
                <option value="Tripura">Tripura</option>
                <option value="Uttar Pradesh">Uttar Pradesh</option>
                <option value="Uttarakhand">Uttarakhand</option>
                <option value="West Bengal">West Bengal</option>
                <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                <option value="Chandigarh">Chandigarh</option>
                <option value="Dadra & Nagar Haveli and Daman & Diu">Dadra & Nagar Haveli and Daman & Diu</option>
                <option value="Delhi">Delhi</option>
                <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                <option value="Puducherry">Puducherry</option>
                <option value="Ladakh">Ladakh</option>
            </select>
            </br>

           
            <input  style="width: 100%;" type="text" name="city" placeholder="Enter City Name" required>
            </br>

           
            <select style="width: 100%;" name="query_type" required>
                <option value="" selected disabled>How do you want to partner with BLive?</option>
                <option value="multi_brand_franchise_owner">Multi Brand Franchise Owner</option>
                <option value="fleet_operator">Fleet Operator</option>
                <option value="enterprise_solution">Enterprise solution</option>
                <option value="want_to_buy_an_EV">Want to buy an EV</option>
            </select>
            </br>

           
            <textarea style="width: 100%;" name="comment_message" rows="5"placeholder="Enter Message" required></textarea>
			</br>
            <input class="hover-button1" type="submit" name="submit" value="Submit">
        </form>
    </div>
    <?php
    return ob_get_clean();
}

// Handle form submission and validation
function handle_master_contact_form() {
    if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["submit"])) {
        $name = sanitize_text_field($_POST["name"]);
        $email = sanitize_email($_POST["email"]);
        $mobile = sanitize_text_field($_POST["mobile"]);
        $state = sanitize_text_field($_POST["state"]);
        $city = sanitize_text_field($_POST["city"]);
        $query_type = sanitize_text_field($_POST["query_type"]);
        $comment_message = esc_textarea($_POST["comment_message"]);

        // Basic form validation
        $errors = array();

        if (empty($name)) {
            $errors[] = 'Please enter your name.';
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Please enter a valid email address.';
        }

        if (empty($mobile) || !preg_match('/^[0-9]{10}$/', $mobile)) {
            $errors[] = 'Please enter a valid 10-digit mobile number.';
        }

        if (empty($state)) {
            $errors[] = 'Please select your state.';
        }

        if (empty($city)) {
            $errors[] = 'Please enter your city name.';
        }

        if (empty($query_type)) {
            $errors[] = 'Please sellect a your query.';
        }
		/*
        if (empty($comment_message)) {
            $errors[] = 'Please enter your message.';
        }
        */

        if (empty($errors)) {
            // No validation errors, proceed with sending the email
            //$to = "rajiv@blive.co.in"; // Replace with your email address

            //$to = $query_type === 'Fleet Operator'||'Franchisee' ? 'rajiv@blive.co.in' : 'rajivcq@email.com';
            $to = '';
            $headers = "From:$name <$email>";
            $subject="Enquery Form From BLive.Co.In";

            
            // $comment_message .= "\n\nState: $state\nCity: $city\nMobile Number: $mobile";
            $body= "\n\nName: $name\nEmail: $email\nMobile Number: $mobile\nState: $state\nCity: $city\nHow do you want to partner with BLive?: $query_type\nYour Message:$comment_message";

            switch ($query_type) {
                case 'multi_brand_franchise_owner':
                case 'want_to_buy_an_EV':
                    $to = 'pratishtha@blive.co.in'; 
                    //$to = 'er.rajiv5587@gmail.com'; 
                    break;
    
                case 'fleet_operator':
                case 'enterprise_solution':
                    $to = 'kishor@blive.co.in'; // Replace with your South India email address
                    break;
    
                default:
                    // Default email address if city is not specified
                    $to = 'default@email.com';
            }

    
            

            $mail_success = wp_mail($to, $subject, $body, $headers);

            if ($mail_success) {
                // Redirect to the thank you page
                wp_redirect(home_url('/thank-you'));
                exit;
            } else {
                echo '<p class="error-message">Sorry, there was an error sending your message. Please try again later.</p>';
            }
        } else {
            // Display validation errors
            echo '<div class="error-message">' . implode('<br>', $errors) . '</div>';
        }
    }
}

// Hook the functions to WordPress actions
add_shortcode('master_contact_form', 'master_contact_form_shortcode');
add_action('init', 'handle_master_contact_form');




// Add the shortcode
function custom_contact_form_shortcode() {
    ob_start();
    ?>
    <style>
       .hover-button1 {
      width:150px !important; 
      background-color: #FFC909 !important; 
      border: 5px solid #FFC909 !important;  
      color: #262325 !important; 
    }

    .hover-button1:hover {
      background-color: #232323 !important; 
      border: 5px solid #232323 !important;  
      color:#FFF !important; 
    } 
    </style>
    <div id="custom-contact-form">
        <form style="width: 100%;" method="post" action="">
            
            <input style="width: 100%;" type="text" name="name" placeholder="Enter Name" required>
			</br>
            
            <input style="width: 100%;" type="email" name="email" placeholder="Enter Email" required>
			</br>

            <input style="width: 100%;" type="tel" name="mobile" pattern="[0-9]{10}" placeholder="Enter 10-digit mobile number" required>
			</br>
           
            <input style="width: 100%;" type="text" name="subject" placeholder="Enter Subject" required>
			</br>
            
            <textarea style="width: 100%;" name="message" rows="5" placeholder="Enter Message" required></textarea>
            </br>

            <input class="hover-button1" type="submit" name="submit" value="Submit">
        </form>
    </div>
    <?php
    return ob_get_clean();
}

// Handle form submission and validation
function handle_custom_contact_form() {
    if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["submit"])) {
        $name = sanitize_text_field($_POST["name"]);
        $email = sanitize_email($_POST["email"]);
        $mobile = sanitize_text_field($_POST["mobile"]);
        $subject = sanitize_text_field($_POST["subject"]);
        $message = esc_textarea($_POST["message"]);

        // Basic form validation
        $errors = array();

        if (empty($name)) {
            $errors[] = 'Please enter your name.';
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Please enter a valid email address.';
        }

        if (empty($mobile) || !preg_match('/^[0-9]{10}$/', $mobile)) {
            $errors[] = 'Please enter a valid 10-digit mobile number.';
        }

        if (empty($subject)) {
            $errors[] = 'Please enter a subject.';
        }

        if (empty($message)) {
            $errors[] = 'Please enter your message.';
        }

        if (empty($errors)) {
            // No validation errors, proceed with sending the email
            $to = "pratishtha@blive.co.in"; // Replace with your email address
            $headers = "From: $name <$email>";

            // Include mobile number in the message body
            $message .= "\n\nMobile Number: $mobile";

            $mail_success = wp_mail($to, $subject, $message, $headers);

            if ($mail_success) {
                // Redirect to the thank you page
                wp_redirect(home_url('/thank-you'));
                exit;
            } else {
                echo '<p class="error-message">Sorry, there was an error sending your message. Please try again later.</p>';
            }
        } else {
            // Display validation errors
            echo '<div class="error-message">' . implode('<br>', $errors) . '</div>';
        }
    }
}

// Hook the functions to WordPress actions
add_shortcode('custom_contact_form', 'custom_contact_form_shortcode');
add_action('init', 'handle_custom_contact_form');




//Talk to EV Expert Form
// Add the shortcode
function custom_contact_form_shortcode2() {
    ob_start();
    ?>
	<style>
       .hover-button1 {
      width:150px !important; 
      background-color: #FFC909 !important; 
      border: 5px solid #FFC909 !important;  
      color: #262325 !important; 
    }

    .hover-button1:hover {
      background-color: #232323 !important; 
      border: 5px solid #232323 !important;  
      color:#FFF !important; 
    } 
    </style>
    <div id="custom-contact-form">
        <form style="width: 100%;" method="post" action="">
            
            
            <input style="width: 100%;" type="text" name="name" placeholder="Enter Name" required>
			</br>
			
            <input style="width: 100%;" type="email" name="email" placeholder="Enter Email" required>
			</br>

            <input style="width: 100%;" type="tel" name="mobile" pattern="[0-9]{10}" placeholder="Enter 10-digit mobile number" required>
			</br>

            
            <select style="width: 100%;" name="state" required>
                <option value="" selected disabled>Select your state</option>
                <option value="Andhra Pradesh">Andhra Pradesh</option>
                <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                <option value="Assam">Assam</option>
                <option value="Bihar">Bihar</option>
                <option value="Chhattisgarh">Chhattisgarh</option>
                <option value="Goa">Goa</option>
                <option value="Gujarat">Gujarat</option>
                <option value="Haryana">Haryana</option>
                <option value="Himachal Pradesh">Himachal Pradesh</option>
                <option value="Jharkhand">Jharkhand</option>
                <option value="Karnataka">Karnataka</option>
                <option value="Kerla">Kerla</option>
                <option value="Madhya Pradesh">Madhya Pradesh</option>
                <option value="Maharashtra">Maharashtra</option>
                <option value="Manipur">Manipur</option>
                <option value="Meghalaya">Meghalaya</option>
                <option value="Mizoram">Mizoram</option>
                <option value="Nagaland">Nagaland</option>
                <option value="Odisha">Odisha</option>
                <option value="Punjab">Punjab</option>
                <option value="Rajasthan">Rajasthan</option>
                <option value="Sikkim">Sikkim</option>
                <option value="Tamil Nadu">Tamil Nadu</option>
                <option value="Telangana">Telangana</option>
                <option value="Tripura">Tripura</option>
                <option value="Uttar Pradesh">Uttar Pradesh</option>
                <option value="Uttarakhand">Uttarakhand</option>
                <option value="West Bengal">West Bengal</option>
                <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                <option value="Chandigarh">Chandigarh</option>
                <option value="Dadra & Nagar Haveli and Daman & Diu">Dadra & Nagar Haveli and Daman & Diu</option>
                <option value="Delhi">Delhi</option>
                <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                <option value="Puducherry">Puducherry</option>
                <option value="Ladakh">Ladakh</option>
                <!-- Add more states as needed -->
            </select>
            </br>

           
            <input  style="width: 100%;" type="text" name="city" placeholder="Enter City Name" required>
            </br>

           
            <input style="width: 100%;" type="text" name="subject" placeholder="Enter Subject" required>
            </br>

           
            <textarea style="width: 100%;" name="coment_message" rows="5"placeholder="Enter Message" required></textarea>
			</br>
            <input class="hover-button1" type="submit" name="submit" value="Submit">
        </form>
    </div>
    <?php
    return ob_get_clean();
}

// Handle form submission and validation
function handle_custom_contact_form2() {
    if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["submit"])) {
        $name = sanitize_text_field($_POST["name"]);
        $email = sanitize_email($_POST["email"]);
        $mobile = sanitize_text_field($_POST["mobile"]);
        $state = sanitize_text_field($_POST["state"]);
        $city = sanitize_text_field($_POST["city"]);
        $subject = sanitize_text_field($_POST["subject"]);
        $comment_message = esc_textarea($_POST["comment_message"]);

        // Basic form validation
        $errors = array();

        if (empty($name)) {
            $errors[] = 'Please enter your name.';
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Please enter a valid email address.';
        }

        if (empty($mobile) || !preg_match('/^[0-9]{10}$/', $mobile)) {
            $errors[] = 'Please enter a valid 10-digit mobile number.';
        }

        if (empty($state)) {
            $errors[] = 'Please select your state.';
        }

        if (empty($city)) {
            $errors[] = 'Please enter your city name.';
        }

        if (empty($subject)) {
            $errors[] = 'Please enter a subject.';
        }
		/*
        if (empty($comment_message)) {
            $errors[] = 'Please enter your message.';
        }
        */

        if (empty($errors)) {
            // No validation errors, proceed with sending the email
            $to = "pratishtha@blive.co.in"; // Replace with your email address
            $headers = "From: $name <$email>";

            // Include state, city, and mobile number in the message body
            // $comment_message .= "\n\nState: $state\nCity: $city\nMobile Number: $mobile";
            $comment_message= "\n\nState: $state\nCity: $city\nMobile Number: $mobile";
            // $body="Hello World";

            $mail_success = wp_mail($to, $subject, $comment_message, $headers);

            if ($mail_success) {
                // Redirect to the thank you page
                wp_redirect(home_url('/thank-you'));
                exit;
            } else {
                echo '<p class="error-message">Sorry, there was an error sending your message. Please try again later.</p>';
            }
        } else {
            // Display validation errors
            echo '<div class="error-message">' . implode('<br>', $errors) . '</div>';
        }
    }
}

// Hook the functions to WordPress actions
add_shortcode('custom_contact_form2', 'custom_contact_form_shortcode2');
add_action('init', 'handle_custom_contact_form2');




// Add the shortcode for for form3
function custom_contact_form_shortcode3() {
    ob_start();
    ?>
    <style>
       .hover-button1 {
      width:150px !important; 
      background-color: #FFC909 !important; 
      border: 5px solid #FFC909 !important;  
      color: #262325 !important; 
    }

    .hover-button1:hover {
      background-color: #232323 !important; 
      border: 5px solid #232323 !important;  
      color:#FFF !important; 
    } 
    </style>
    <div id="custom-contact-form">
        <form style="width: 100%;" method="post" action="">
            
            <input style="width: 100%;" type="text" name="name" placeholder="Enter Name" required>
			</br>
            
            <input style="width: 100%;" type="email" name="email" placeholder="Enter Email" required>
			</br>

            <input class="hover-button1" type="submit" name="submit" value="Submit">
        </form>
    </div>
    <?php
    return ob_get_clean();
}

// Handle form submission and validation
function handle_custom_contact_form3() {
    if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["submit"])) {
        $name = sanitize_text_field($_POST["name"]);
        $email = sanitize_email($_POST["email"]);
        $mobile = sanitize_text_field($_POST["mobile"]);
        $subject = sanitize_text_field($_POST["subject"]);
        $message = esc_textarea($_POST["message"]);

        // Basic form validation
        $errors = array();

        if (empty($name)) {
            $errors[] = 'Please enter your name.';
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Please enter a valid email address.';
        }

        if (empty($mobile) || !preg_match('/^[0-9]{10}$/', $mobile)) {
            $errors[] = 'Please enter a valid 10-digit mobile number.';
        }

        if (empty($subject)) {
            $errors[] = 'Please enter a subject.';
        }

        if (empty($message)) {
            $errors[] = 'Please enter your message.';
        }

        if (empty($errors)) {
            // No validation errors, proceed with sending the email
            $to = "rajiv@blive.co.in"; // Replace with your email address
            $headers = "From: $name <$email>";

            // Include mobile number in the message body
            $message .= "\n\nMobile Number: $mobile";

            $mail_success = wp_mail($to, $subject, $message, $headers);

            if ($mail_success) {
                // Redirect to the thank you page
                wp_redirect(home_url('/thank-you'));
                exit;
            } else {
                echo '<p class="error-message">Sorry, there was an error sending your message. Please try again later.</p>';
            }
        } else {
            // Display validation errors
            echo '<div class="error-message">' . implode('<br>', $errors) . '</div>';
        }
    }
}

// Hook the functions to WordPress actions
add_shortcode('custom_contact_form3', 'custom_contact_form_shortcode3');
add_action('init', 'handle_custom_contact_form3');





